
const form = document.getElementById("formAtlet");
const tabel = document.getElementById("tabelAtlet");
const hasilAnalisis = document.getElementById("hasilAnalisis");

const grafikAtlet = new Chart(
  document.getElementById("grafikAtlet"),
  {
    type: "bar",
    data: {
      labels: [],
      datasets: [
        {
          label: "Vertical Jump (cm)",
          data: [],
          backgroundColor: "#147d76",
          borderRadius: 6
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        y: {
          beginAtZero: true,
          title: {
            display: true,
            text: "Tinggi lompatan (cm)"
          }
        },
        x: {
          title: {
            display: true,
            text: "Nama atlet"
          }
        }
      }
    }
  }
);


let daftarAtlet = [];

form.addEventListener("submit", function(event) {
  event.preventDefault();

  const nama = document.getElementById("nama").value.trim();
  const cabor = document.getElementById("cabor").value;
  const sprint = Number(document.getElementById("sprint").value);
  const agility = Number(document.getElementById("agility").value);
  const lompat = Number(document.getElementById("lompat").value);

  if (
    !nama ||
    !Number.isFinite(sprint) ||
    !Number.isFinite(agility) ||
    !Number.isFinite(lompat) ||
    sprint <= 0 ||
    agility <= 0 ||
    lompat < 0
  ) {
    alert("Periksa kembali data yang dimasukkan.");
    return;
  }

  const atlet = {
    id: Date.now() + Math.random(),
    nama: nama,
    cabor: cabor,
    sprint: sprint,
    agility: agility,
    lompat: lompat
  };

  daftarAtlet.push(atlet);

  tampilkanData();
  form.reset();
});

function buatSel(baris, isi) {
  const sel = document.createElement("td");
  sel.textContent = isi;
  baris.appendChild(sel);
}

function tampilkanData() {
  tabel.replaceChildren();

  if (daftarAtlet.length === 0) {
    const baris = document.createElement("tr");
    const sel = document.createElement("td");

    sel.colSpan = 6;
    sel.className = "empty";
    sel.textContent = "Belum ada data atlet.";

    baris.appendChild(sel);
    tabel.appendChild(baris);
  }

  daftarAtlet.forEach(function(atlet) {
    const baris = document.createElement("tr");

    buatSel(baris, atlet.nama);
    buatSel(baris, atlet.cabor);
    buatSel(baris, atlet.sprint.toFixed(2));
    buatSel(baris, atlet.agility.toFixed(2));
    buatSel(baris, atlet.lompat.toFixed(1));

    const selAksi = document.createElement("td");
    const tombolHapus = document.createElement("button");

    tombolHapus.textContent = "Hapus";
    tombolHapus.className = "delete-btn";
    tombolHapus.type = "button";

    tombolHapus.addEventListener("click", function() {
      daftarAtlet = daftarAtlet.filter(function(item) {
        return item.id !== atlet.id;
      });

      tampilkanData();
    });

    selAksi.appendChild(tombolHapus);
    baris.appendChild(selAksi);
    tabel.appendChild(baris);
  });

  hitungStatistik();
}

function rataRata(data, kunci) {
  if (data.length === 0) return 0;

  const total = data.reduce(function(jumlah, atlet) {
    return jumlah + atlet[kunci];
  }, 0);

  return total / data.length;
}

function hitungStatistik() {
  const total = daftarAtlet.length;

  document.getElementById("totalAtlet").textContent = total;

  if (total === 0) {
    document.getElementById("rataSprint").textContent = "-";
    document.getElementById("rataLompat").textContent = "-";
    hasilAnalisis.textContent =
      "Tambahkan data atlet untuk melihat analisis.";
    return;
  }

  const avgSprint = rataRata(daftarAtlet, "sprint");
  const avgAgility = rataRata(daftarAtlet, "agility");
  const avgLompat = rataRata(daftarAtlet, "lompat");

  document.getElementById("rataSprint").textContent =
    avgSprint.toFixed(2);

  document.getElementById("rataLompat").textContent =
    avgLompat.toFixed(1) + " cm";

  const sprintTercepat = daftarAtlet.reduce(function(terbaik, atlet) {
    return atlet.sprint < terbaik.sprint ? atlet : terbaik;
  });

  const agilityTercepat = daftarAtlet.reduce(function(terbaik, atlet) {
    return atlet.agility < terbaik.agility ? atlet : terbaik;
  });

  const lompatTertinggi = daftarAtlet.reduce(function(terbaik, atlet) {
    return atlet.lompat > terbaik.lompat ? atlet : terbaik;
  });

  hasilAnalisis.replaceChildren();

  const ringkasan = [
    "Jumlah atlet yang tercatat: " + total + " orang.",
    "Rata-rata sprint 20 meter: " + avgSprint.toFixed(2) + " detik.",
    "Rata-rata tes agility: " + avgAgility.toFixed(2) + " detik.",
    "Rata-rata vertical jump: " + avgLompat.toFixed(1) + " cm.",
    "Waktu sprint terendah: " + sprintTercepat.nama +
      " (" + sprintTercepat.sprint.toFixed(2) + " detik).",
    "Waktu agility terendah: " + agilityTercepat.nama +
      " (" + agilityTercepat.agility.toFixed(2) + " detik).",
    "Hasil vertical jump tertinggi: " + lompatTertinggi.nama +
      " (" + lompatTertinggi.lompat.toFixed(1) + " cm)."
  ];

  ringkasan.forEach
  grafikAtlet.data.labels = daftarAtlet.map(function(atlet) {
    return atlet.nama;
  });

  grafikAtlet.data.datasets[0].data = daftarAtlet.map(
    function(atlet) {
      return atlet.lompat;
    }
  );

  grafikAtlet.update();
  (function(teks) {
    const paragraf = document.createElement("p");
    paragraf.textContent = teks;
    hasilAnalisis.appendChild(paragraf);
  });
}